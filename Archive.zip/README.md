# capture_element
chrome extention takes a screen shot of one element defined by it's css selector
