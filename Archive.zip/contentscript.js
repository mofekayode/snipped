// chrome.runtime.onMessage.addListener((message, sender) => {
// 	console.log('incontentscritp')
// 	const { dataUrl } = message;
// 	console.log(dataUrl,'message')
//     localStorage.setItem('base64Url', dataUrl);
//   });